package its.potosiccuno.StringECharacter;

public class Character {
	/*Scrivere un metodo che ritorni il numero di lettere maiuscole in un
	 * oggetto String passato al metodo come parametro.
	 * Il metodo di classe isUpperCase della classe Character restituisce true se il
	 * carattere passato come argomento � maiuscolo.
	 * */
	public Character() {
		//costruito
	}
		
	

}
