package its.potosiccuno.TrovaNumeriPrimi;

public class Main {

	public static void main(String[] args) {
		
		/*Un numero primo � un numero maggiore di uno e divisibile solo per se stesso e uno.
		 * Ad esempio: 2, 3, 5, 7 e 11 sono numeri primi.
		 * Scrivere un metodo che restituisce true se l�argomento � un numero primo.
		 * Scrivere un altro metodo che stampa tutti i fattori di un numero quando questo non � primo.
		 * */
		
		
		for(int i = 1; i <= 10000; i++)
        {
            int fattore = 0;
            int j = 1;

            while(j <= i)
            {
                if(i % j == 0)
                {
                    fattore++;
                }
                j++;
            }
            if (fattore == 2)
            {
                System.out.println(i);
            }
        }

	}

}


