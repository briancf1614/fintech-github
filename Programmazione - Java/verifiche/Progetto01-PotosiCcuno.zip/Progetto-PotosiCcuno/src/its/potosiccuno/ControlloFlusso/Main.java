package its.potosiccuno.ControlloFlusso;
import java.util.Scanner ;

public class Main {

	public static void main(String[] args) {
		/*Scrivere un�applicazione per stampare i numeri da 1 a N nel seguente modo:
		 * 1 2 3 4 5 6 7 8 9 10
		 * 11 12 13 14 15 16 17 18 19 20
		 * 21 22 23 ...
		 * Acquisire il numero intero N da scanner e stampare la serie
		 */
		
		Scanner input = new Scanner ( System . in );
		System.out.println(" Quanti numeri vuoi inserire ?");
		
		
		int divisibile10=0;
		int numero =0;
		int num = input.nextInt ();
		
		for (int i=0; i<num; i++) {
			divisibile10+=10;
			numero=+1;
			
			System.out.println(i);
			if(num%divisibile10==numero) {
				System.out.println("sfkdfsad");
				
				}
				
			}
		input.close();
		
			}


	}

		
