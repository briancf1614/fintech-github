package its.potosiccuno.classi;

public class A {
	int a1=0;
	
	/*
	 * Si progetti una classe A affinch� la classe Test compili ed il risultato
	 * dell'esecuzione sia:
	 * 5
	 * 0
	 * 10
	 * 0
	 * 
	 * */

	public A() {
		//a costruito
		
	}
	
	public A(int a1) {
		this.a1=a1;

	}
	
	
	public int raddoppiaN() {
		int n=this.a1;
		
		System.out.println(a1*2);
		
		
		return n*2;
	}
	public int getN() {
		return a1;
	}


	
	
}
