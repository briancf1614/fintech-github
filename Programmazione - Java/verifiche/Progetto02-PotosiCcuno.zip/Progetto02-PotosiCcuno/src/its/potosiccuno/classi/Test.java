package its.potosiccuno.classi;

	public class Test {
		/*
		 * Si progetti una classe A affinch� la classe Test compili ed il risultato
		 * dell'esecuzione sia:
		 * 5
		 * 0
		 * 10
		 * 0
		 * 
		 * */
			 public static void main(String[] args) {
				 
				 A a1 = new A(5);
				 A a2 = new A();
				 System.out.println(a1.getN());
				 System.out.println(a2.getN());
				 a1.raddoppiaN();
				 a2.raddoppiaN();
				 System.out.println(a1.getN());
				 System.out.println(a2.getN());
				 
			 }
			
			}

	