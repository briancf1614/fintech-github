package its.potosiccuno.libretti.di.risparmio;

public class LibrettoDemo extends Libreto {
	

	


}
