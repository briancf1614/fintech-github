package its.potosiccuno.libretti.di.risparmio;

public class Libreto {
	
	int deposito=0;
	int prelievo=0;
	int storiale=0;
	
	public Libreto() {
		
	}

	public int getDeposito() {
		return deposito;
	}

	public void setDeposito(int deposito) {
		this.deposito =this.deposito + deposito;
	}

	public int getPrelievo() {
		return prelievo;
	}

	public void setPrelievo(int prelievo) {
		this.prelievo =this.prelievo+ prelievo;
	}

	public int getStoriale() {
		return storiale;
	}

	public void setStoriale(int storiale) {
		this.storiale = storiale;
	}
	

}
