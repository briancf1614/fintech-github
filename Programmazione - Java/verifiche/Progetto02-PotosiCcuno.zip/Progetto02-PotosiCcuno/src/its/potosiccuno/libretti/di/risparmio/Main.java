package its.potosiccuno.libretti.di.risparmio;

public class Main {

	public static void main(String[] args) {
		/*Scrivere un applicazione per la gestione di libretti di risparmio.
		 * Il programma pu� gestire diversi libretti di risparmio.
		 * Per ogni libretto, l�utente titolare pu� depositare una somma, prelevare una
		 * somma, e chiedere i movimenti ed il saldo.
		 * Sia i prelievi, sia i depositi sono numerati in ordine crescente.
		 * In una classe LibrettoDemo, istanziare qualche Libretto di prova, testare i
		 * metodi e stampare l'elenco dei movimenti e il saldo di ciascun libretto
		*/
		
		Libreto libreto1=new Libreto();
		Libreto libreto2=new Libreto();
		Libreto libreto3=new Libreto();
		
	
		
	}

}
