package com.adde.services;

import java.util.List;

import com.adde.entities.Ricetta;

public interface RicettaService {
	
	List<Ricetta> getAllRicette();
	Ricetta getRicetta(int id);
	List<Ricetta> getAllRicetteByIngrediente(String ingrediente);
	Ricetta addRicetta(Ricetta r);
	
}