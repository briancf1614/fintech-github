package com.adde.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adde.entities.Ricetta;
import com.adde.repos.RicettaDAO;

@Service
public class RicettaServiceImpl implements RicettaService {

	@Autowired
	private RicettaDAO repo;
	
	@Override
	public List<Ricetta> getAllRicette() {
		return repo.findAll();
	}

	@Override
	public Ricetta getRicetta(int id) {
		return repo.findById(id).get();
	}

	@Override
	public List<Ricetta> getAllRicetteByIngrediente(String ingrediente) {
		return null;
	}

	@Override
	public Ricetta addRicetta(Ricetta r) {
		return repo.save(r);					//Si usa per creare e aggiornare valori el db
	}

}
