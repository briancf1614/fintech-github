package com.adde.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.adde.entities.Ricetta;
import com.adde.services.RicettaService;

@Controller
@RequestMapping("")										//rotta raggiunta con url che finisce per /
public class Ricette {
	
	@Autowired				
	private RicettaService service;
	
	@GetMapping
	@ResponseBody										//per dare la risposta nel body
	public List<Ricetta> getAll(){
		return service.getAllRicette();
	}
	
	@PostMapping
	@ResponseBody
	public Ricetta addRicetta(@RequestBody Ricetta r){	//requestbody per prendere dal body
		return service.addRicetta(r);
	}
	
}
