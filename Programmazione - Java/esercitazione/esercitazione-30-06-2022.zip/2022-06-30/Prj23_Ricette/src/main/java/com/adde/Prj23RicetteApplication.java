package com.adde;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Prj23RicetteApplication {

	public static void main(String[] args) {
		SpringApplication.run(Prj23RicetteApplication.class, args);
	}

}
