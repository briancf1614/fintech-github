package com.adde.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.adde.entities.Ricetta;

@Repository//Se ci bastano i metodi base di CRUD non dobbiamo implementare nulla di nuovo
public interface RicettaDAO extends JpaRepository<Ricetta, Integer> {
}