package com.adde.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.adde.entities.Alimento;

@Repository //Opzionale: contiene i repositori, di solito sono molti
public interface AlimentoDAO extends JpaRepository<Alimento, Integer> {
	//strato piu' basso che accede al db
	//Scrivo i metodi personalizzati che dovranno accedere al DB
}
