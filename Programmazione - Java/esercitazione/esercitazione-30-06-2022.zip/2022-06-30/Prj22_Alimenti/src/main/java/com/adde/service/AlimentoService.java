package com.adde.service;

import java.util.List;

import com.adde.entities.Alimento;

public interface AlimentoService {
	//Lista dei metodi che verranno
	// utilizzati dall'interfaccia
	List<Alimento> getAlimenti();
	Alimento getAlimento(int id);
	
	
}