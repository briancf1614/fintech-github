package com.adde;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Prj22AlimentiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Prj22AlimentiApplication.class, args);
	}

}
