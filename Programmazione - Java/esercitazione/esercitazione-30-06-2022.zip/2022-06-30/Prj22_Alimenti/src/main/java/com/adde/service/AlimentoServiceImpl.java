package com.adde.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
//stereotype: gli stereotipi dell'annotazioni di Spring
import org.springframework.stereotype.Service;

import com.adde.entities.Alimento;
import com.adde.repos.AlimentoDAO;
//Collegamento con il DAO
@Service
public class AlimentoServiceImpl implements AlimentoService {
	
	//Quando arriva una chiamata che necessita di questo
	// oggetto,spring lo crea e lo distrugge dopo
	// l'utilizzo. Quindi l'oggetto necessario viene creato
	// da Spring
	@Autowired
	private AlimentoDAO repo;
	
	@Override
	public List<Alimento> getAlimenti() {
		return repo.findAll();
	}

	@Override
	public Alimento getAlimento(int id) {
		return repo.findById(id).get();
	}

}
