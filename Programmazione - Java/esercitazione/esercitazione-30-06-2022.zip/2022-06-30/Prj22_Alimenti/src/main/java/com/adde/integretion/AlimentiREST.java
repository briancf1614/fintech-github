package com.adde.integretion;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adde.entities.Alimento;
import com.adde.service.AlimentoService;

@RestController
@RequestMapping("api")
public class AlimentiREST {
/*
 * 	l'elenco delle categorie con l'indicazione delle quantità di alimenti afferenti a tale categoria;
 *	l'elenco degli alimenti data una categoria
 *	l'elenco degli alimenti data una parola contenuta nel nome alimento
 *	il singolo alimento dato l'id
	il singolo alimento dato il nome
 */
	@Autowired
	private AlimentoService service;
	
	@GetMapping
	public List<Alimento> getAll(){
		return service.getAlimenti();
	}
	
	@GetMapping("categorie")
	public List<String> getCategorie(){
		return service.getAlimenti()				//oggetto complesso
				.stream()							//
				.map(a -> a.getCategoria())			//Ottengo solo la stringa categoria
				.distinct()							// come in SQL
				.sorted()							//le riordino
				.toList();							//le ri-colleziono in una lista grazie java 17
	}
	
	@GetMapping("alimenti/{categoria}")				//{placeholder}
	public List<Alimento> getAlimentiByCat(@PathVariable("categoria") String categoria){
		return service.getAlimenti()		
				.stream()
				.filter(a -> a.getCategoria()		//filtro per categoria	
						.equalsIgnoreCase(categoria))
				.toList();					
	}
	
	@GetMapping("alimenti/nome/{prodotto}")
	public List<Alimento> getAlimentiByProdotto(@PathVariable("prodotto") String prodotto){
		return service.getAlimenti()
				.stream()
				.filter(a -> a.getProdotto()	
						.contains(prodotto))		// che contiene(prodotto)
				.toList();					
	}
	
}
