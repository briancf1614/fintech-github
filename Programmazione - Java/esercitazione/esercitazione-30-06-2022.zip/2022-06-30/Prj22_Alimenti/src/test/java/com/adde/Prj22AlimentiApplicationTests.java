package com.adde;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prj22AlimentiApplicationTests {

	@Test
	void contextLoads() {
	}

}
