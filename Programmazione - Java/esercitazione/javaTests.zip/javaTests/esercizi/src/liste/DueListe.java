package liste;

import java.util.Scanner;
import  java.util.ArrayList;
public class DueListe {

	public static void main(String[] args) {
		int[] list1=new int[5];
		int[] list2=new int[5];
		
			Scanner sc = new Scanner(System.in);
			for(int i = 0;i<list1.length;i++) {
				System.out.println("inserisci un numero lista1:");
				list1[i]=sc.nextInt();
			}
			
			
			for(int i=0;i<list2.length;i++) {
				System.out.println("inserisci un numero lista2:");
				list2[i]=sc.nextInt();
				}
			
			sc.close();
			
			for(int i=0;i<list1.length;i++) {
				int sum;
				sum= list1[i]+list2[i];
				System.out.println("somma dei numeri delle due liste: "+sum);
			}

	}

}
