package Multipli;

import java.util.ArrayList;
import java.util.Scanner;

public class Multipli {
	/*Scrivere un programma MediaMultipliDiTre che chiede all�utente 
	 * di inserire una sequenza di interi (chiedendo prima quanti 
	 * numeri voglia inserire) e poi stampa la media di tutti i 
	 * numeri inseriti che siano divisibili per tre.
	 * Per esempio, se si immettono i valori 5, 8, 9, 12,
	 * 7, 6 ,1 il risultato stampato dovr� essere 9.*/

	
	
	public static double CalcolaMedia(ArrayList<Integer> lista) {
		double media=0;
		
		for(Integer x : lista) {
			media+=x;
		}
		return media/lista.size();
	}
	public static void main(String[] args) {
		Scanner sc =new Scanner (System.in);
				
		int qtaNumeri=0;
		int i;
		ArrayList<Integer>input =new ArrayList<Integer>();
		
		System.out.println("quanti numeri vuoi inserire?");
		qtaNumeri=sc.nextInt();
		
		for(i=0;i<qtaNumeri;i++) {
			int memo=0;
			System.out.println("inserisci il numero"+i);
			memo=sc .nextInt();
			if(memo%3==0) {
				input.add(memo);
			}
		}
		
		System.out.println(CalcolaMedia(input));
	}


}
