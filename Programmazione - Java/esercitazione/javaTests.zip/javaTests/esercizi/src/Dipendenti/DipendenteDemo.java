package Dipendenti;

import java.util.Arrays;
import java.util.List;

public class DipendenteDemo {

	public static void main(String[] args) {
		Dipendente[] dipendenti= {
			new Dipendente("Mario","Rossi",2280),
			new Dipendente("Luigi","Lopez",2280),
			new Dipendente("Wario","Pitto",3280),
			new Dipendente("Ilario","Roquez",5280),
			new Dipendente("Dario","Vialli",1280),
			new Dipendente("Madario","Bianchi",1580)
		};
		List<Dipendente> listaDipendenti=Arrays.asList(dipendenti);
		tabulato(listaDipendenti);
		//System.out.println(stipendioMedio(listaDipendenti));
		System.out.println(listaDipendenti.stream().mapToDouble(d->d.getStipendio()).average());
		
		listaDipendenti
			.stream()
			.max(d1,d2)-> Double.compare(d1.getStipendio(),d2.getStipendio()))
			.ifPresent(System.out::println);
			.forEach(System.out::println);
	}
	public static void tabulato(List<Dipendente> dipendenti) {
		for(var d: dipendenti) {
			
			System.out.println(d.toString());
		}
	}
	
	public static double stipendioMedio(List<Dipendente> dipendenti) {
		double sum=0;
		for (Dipendente d: dipendenti) {
			sum+=d.getStipendio();
		}
		double media=sum/dipendenti;
				return media;
	}
}
