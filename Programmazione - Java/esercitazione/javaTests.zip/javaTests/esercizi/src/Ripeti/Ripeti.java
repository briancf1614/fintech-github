package Ripeti;

import java.util.Scanner;

public class Ripeti {

	public static void ripetiStringa(String s, int n) {
		if(n<0) {
			System.out.println("errore");
		}else {
				System.out.println(s.repeat(n));
			}
		}
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		String s=scanner.nextLine();
		int n=scanner.nextInt();
		ripetiStringa(s,n);
		scanner.close();
	}
}
		
	


