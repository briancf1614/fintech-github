package Suddividi;

import java.util.Scanner;

public class Suddividi {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Inserisci una frase: ");
		String frase =sc.nextLine();
		String[] parole=frase.split(" ");
		
		for(String s :parole) {
			System.out.println(s);
		}
	}
}
