package Stampa;

import java.util.Iterator;

public class Stampa {

	public static void main(String[] args) {
		char val='#';
		for(int i=0; i<=6;i++) {
			for(int j=0;j<i;j++){
				System.out.println("\n");
			}
		}

	}

}
