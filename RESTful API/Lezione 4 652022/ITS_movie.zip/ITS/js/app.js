
function insertPostfromForm(){
	let title = document.getElementById('title');
	let body = document.getElementById('body');
	console.log(title.value);
	console.log(body.value);
	createPost(title.value, body.value);

}

async function createPost(title, body){
		let url='https://jsonplaceholder.typicode.com/posts';
	

	fetch(url, {
	  method: 'POST',
	  body: JSON.stringify({
	    title: title,
	    body: body,

	  }),
	  headers: {
	    'Content-type': 'application/json; charset=UTF-8',
	  },
	})
	  .then((response) => response.json())
	  .then((json) => console.log(json));

}

async function getPosts(){
		let url='https://jsonplaceholder.typicode.com/posts';
		try{
			let response = await fetch(url);
			return await response.json();
		} catch (error){
			console.log(error);
		} 
	}	
	
async function renderPosts(){
	let posts = await getPosts();
	let html = '';
	posts.forEach(  post => {
			let htmlItem = `
					<div class="singlepost">
					<h2>${post.title}</h2>
					<div class="singlebody">
						${post.body}
					</div>	
					</div>	
				`;
				
				html += htmlItem;
			} 
		);
		let container = document.querySelector('.container');
		container.innerHTML = html;
		
}


async function getMovies(){
		let url='output.json';
		try{
			let response = await fetch(url);
			return await response.json();
		} catch (error){
			console.log(error);
		} 
	}
	
async function renderMovies(){
	let movies = await getMovies();
	let html = '';
	movies.forEach(  movie => {
			let htmlItem = `
					<div class="singlepost">
					<h2>${movie.MovieTitle}</h2>
					<div class="singlebody">
						${movie.MovieGenre}
					</div>	
					</div>	
				`;
				
				html += htmlItem;
			} 
		);
		let container = document.querySelector('.container');
		container.innerHTML = html;
		
}
//renderPosts();
renderMovies();
