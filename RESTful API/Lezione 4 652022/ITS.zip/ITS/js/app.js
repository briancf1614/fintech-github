
async function getMovies(){	
		let url='https://bestmovie.spinforward.it/api/v1/movie/'; 
		try{
			let response = await fetch(url);
			return await response.json();
		} catch (error){
			console.log(error);
		} 
	}
	
async function renderMovies(){
	let movies = await getMovies();
	let html = '';
	movies.forEach(  movie => {
			let htmlItem = `
					<div class="singlepost">
					<h2>${movie.MovieTitle}</h2>
					<div class="singlebody">
						${movie.MovieGenre}
					</div>	
					</div>	
				`;
				
				html += htmlItem;
			} 
		);
		let container = document.querySelector('.container');
		container.innerHTML = html;
		
}

renderMovies();
