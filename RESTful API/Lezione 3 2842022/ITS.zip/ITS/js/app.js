async function getPosts(){
		let url='https://jsonplaceholder.typicode.com/posts';
		try{
			let response = await fetch(url);
			return await response.json();
		} catch (error){
			console.log(error);
		} 
	}	
	
async function renderPosts(){
	let posts = await getPosts();
	let html = '';
	posts.forEach(  post => {
			let htmlItem = `
					<div class="singlepost">
					<h2>${post.title}</h2>
					</div>	
				`;
				
				html += htmlItem;
			} 
		);
		let container = document.querySelector('.container');
		container.innerHTML = html;
		
}
renderPosts();
