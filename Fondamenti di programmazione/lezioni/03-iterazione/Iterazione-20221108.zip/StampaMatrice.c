/*


**********
**********
**********

...

**********

*/
#include <stdio.h>

int main(){
	
	int righe, colonne;
	
	char c;
	printf("Carattere da stampare: ");
	scanf("%c",&c);
	
	printf("Numero di righe: ");
	scanf("%d",&righe);
	
	printf("Numero di colonne: ");
	scanf("%d",&colonne);
	
	
	
	int i, j;
	for(i=0;i<righe;i++){
		for(j=0;j<colonne;j++)
			printf("%c",c);
		printf("\n");
			
	}
	
}


