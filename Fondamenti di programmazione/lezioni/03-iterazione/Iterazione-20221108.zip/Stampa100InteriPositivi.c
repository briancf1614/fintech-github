/* stampa dei primi 100 numeri naturali */

#include <stdio.h>

int main(){
	
	int count = 0;
	
	while(count<100){
		printf("\t%d",count);
		count++; //count = count + 1;  incremento
	}
		
}
