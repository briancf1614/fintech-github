/* 
Dati N numeri interi in input, visualizzare il max
 */
#include <stdio.h>

int main(){
	
	int n;
	int flag; //stato dell'errore
	do{	
		flag = 0; //non ci sono errori
		printf("Inserisci un numero intero strettamente positivo (>0): ");
		scanf("%d",&n);
	
		if(n<=0){
			printf("\nErrore\n\n");
			flag=1; //si � verificato un errore
		}
			
	}while(flag==1);

	int max; //variabile che contiene il valore max inserito
	
	int i; //contatore per il ciclo for
	int numero; //variabile per acquisire da input il numero di volta in volta
	for(i=0;i<n;i++){
		printf("Inserisci un numero: ");
		scanf("%d",&numero);
		if(numero > max || i==0)
			max = numero;
	
	}
	
	printf("\n\nStampa dei risultati\n\n");
	printf("Max: %d\n",max);				
}
