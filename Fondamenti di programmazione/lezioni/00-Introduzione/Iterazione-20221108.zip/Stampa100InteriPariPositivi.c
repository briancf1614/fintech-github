/* stampa dei primi 100 numeri pari positivi */

#include <stdio.h>

int main(){
	
	int count = 0;
	
	while(count<100){
		printf("\t%d",count*2);
		count++; 
	}
		
}
