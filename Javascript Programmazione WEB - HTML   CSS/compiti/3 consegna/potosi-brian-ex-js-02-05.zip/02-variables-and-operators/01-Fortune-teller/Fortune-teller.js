let number_of_children,partners_name,geographic_location,job_title;
number_of_children=2;
partners_name='Maria';
geographic_location='Turin';
job_title='teacher';

console.log("you will be a " + job_title+" in "+geographic_location+" and married to "+partners_name+" with "+number_of_children+" kids");
