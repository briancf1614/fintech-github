
let corrent_age=23,maximun_age=53,coffee_day=2,years_of_coffee=30,totale_coffe;
totale_coffe=years_of_coffee*365*2;
console.log(`You will need${totale_coffe} cups of coffee to last you until the ripe old age of ${maximun_age}`);
