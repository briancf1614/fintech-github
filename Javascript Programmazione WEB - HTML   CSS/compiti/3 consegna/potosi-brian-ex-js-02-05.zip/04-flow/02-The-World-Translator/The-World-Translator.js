function helloWorld(language_code){
    if(language_code=="en"){
    console.log("Hello, World");
    }
    if(language_code=="es"){
    console.log("Hola Mundo");
    }
    if(language_code=="de"){
    console.log("Hallo Welt");
    }
}
helloWorld("en");
helloWorld("es");
helloWorld("de");