function pluralize(noun,number){

}