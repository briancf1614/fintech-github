function Geometry_library(radius){
    circumference=Math.PI*2*radius
    console.log("The circumference is "+circumference);
}
Geometry_library(2);
Geometry_library(9);
Geometry_library(50);