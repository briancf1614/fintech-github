function calculateDogAge(dogs_age_in_human_years){
    dogs_age_in_human_years=dogs_age_in_human_years*7;
    console.log("Your dog is "+dogs_age_in_human_years+"years old in dog years!")
}
calculateDogAge(20);
calculateDogAge(7);
calculateDogAge(14);
