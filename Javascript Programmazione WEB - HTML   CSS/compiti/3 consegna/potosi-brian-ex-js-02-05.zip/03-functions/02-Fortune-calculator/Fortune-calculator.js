function tellFortune(number_of_children,partners_name,geographic_location,job_title){
    console.log("You will be a "+job_title+" in "+geographic_location+", and married to "+partners_name+" with "+number_of_children+" kids.")
}
tellFortune(3,"Sandra","peru","architech");
tellFortune(1,"Brian","chile","doctor");
tellFortune(4,"Bictor","peru","president");
