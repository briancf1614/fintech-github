function Money(amount){
    console.log(amount+" Dollars");
}
Money(100);