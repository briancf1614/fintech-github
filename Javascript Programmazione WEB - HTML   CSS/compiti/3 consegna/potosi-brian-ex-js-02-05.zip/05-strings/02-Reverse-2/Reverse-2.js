function reverse(word){
for(let i=5;i>=0;i--){
    console.log(word[i]);
}
}
reverse("foobar");