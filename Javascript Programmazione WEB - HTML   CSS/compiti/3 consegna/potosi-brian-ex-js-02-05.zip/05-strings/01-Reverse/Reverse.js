function printReverse(word) {
    
    for(let i=5;i>=0;i--){
        
        console.log(word.charAt(i));
    }
}
printReverse("foobar");