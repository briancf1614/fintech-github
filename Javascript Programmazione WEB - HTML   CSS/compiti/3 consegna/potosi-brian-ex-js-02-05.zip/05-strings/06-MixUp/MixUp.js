function MixUp(string1,string2){
    console.log(string1 +" "+ string2);
}
MixUp("dog","dinner");