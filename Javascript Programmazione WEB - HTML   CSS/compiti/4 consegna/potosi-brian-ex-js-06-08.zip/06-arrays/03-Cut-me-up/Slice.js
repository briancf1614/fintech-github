const fruits = ["Banana", "Orange", "Lemon", "Apple", "Mango", "lala", "loreto", "tulez", "Lopita"];
console.log("scrivi tre elementi qualsiasi");
console.log("qua ci sono tre elementi del array"+fruits.slice(3,6));