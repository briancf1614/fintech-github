var fruits = ["Fragola", "Orange", "Apple", "Mango", "lala", "nana", "tata", "sese", "fefe", "gaga", "yaya", "rara"];
fruits.splice(4, 3, "Lemon", "Kiwi");
console.log("qua ho inserito 2 elementi nelllo spazio 4 ed eliminato 2: "+fruits);
