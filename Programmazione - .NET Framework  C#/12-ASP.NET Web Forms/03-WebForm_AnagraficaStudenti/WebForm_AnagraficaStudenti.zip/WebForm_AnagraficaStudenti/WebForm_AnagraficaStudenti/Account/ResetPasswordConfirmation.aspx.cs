﻿using System.Web.UI;

namespace WebForm_AnagraficaStudenti.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}