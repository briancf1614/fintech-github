﻿using System.Web.UI;

namespace WebForm_AccessoDB.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}