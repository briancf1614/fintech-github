﻿using System;
using System.Collections.Generic;

namespace PotosiEsercitazione
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Venditore> Lista = new List<Venditore>();
            Lista.Add(new Venditore { Nome = "Brian", Cognome = "Potosi", Stipendio = 35000, Settore = "Auto" });
            Lista.Add(new Venditore { Nome = "Jorge", Cognome = "perez", Stipendio = 60000, Settore = "Moto" });
            Lista.Add(new Venditore { Nome = "Peter", Cognome = "Bertolino", Stipendio = 40000, Settore = "Moto" });
            Lista.Add(new Venditore { Nome = "Luca", Cognome = "Diaz", Stipendio = 30000, Settore = "Auto" });

            List<Meccanico> Lista2 = new List<Meccanico>();
            Lista.Add(new Venditore { Nome = "Pepe", Cognome = "Lopez", Stipendio = 55000, Settore = "Moto" });
            Lista.Add(new Venditore { Nome = "Daniel", Cognome = "Rodrighez", Stipendio = 50000, Settore = "Auto" });

            Console.WriteLine("1 per inserire");
            Console.WriteLine("");
            int num = int.Parse(Console.ReadLine());
            if (num == 1)
            {
                Console.WriteLine(Lista);
                
            }
            else if(num==2)
            {
                Console.WriteLine(Lista2);
            }
        }
    }
}
