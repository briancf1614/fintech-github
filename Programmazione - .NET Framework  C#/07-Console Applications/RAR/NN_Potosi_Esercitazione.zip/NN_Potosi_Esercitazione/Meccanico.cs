﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PotosiEsercitazione
{
    class Meccanico : Persona
    {
        public string Tipologia { get; set; }
        public override double Tredicesima()
        {
            double a = (93 * Stipendio) / 100;
            Stipendio = Stipendio + a;
            return Stipendio;
        }
        public override string ToString()
        {
            return $"{{{nameof(Tipologia)}={Tipologia}, {nameof(Nome)}={Nome}, {nameof(Cognome)}={Cognome}, {nameof(Stipendio)}={Stipendio.ToString()}}}";
        }
    }
}
