﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PotosiEsercitazione
{
    class Venditore : Persona
    {
        public string Settore { get; set; }
        public override double Tredicesima()
        {
            double a = (91 * Stipendio) / 100;
            Stipendio = Stipendio + a;
            return Stipendio;
        }
        public abstract int Clone()
        {

        }
        public override string ToString()
        {
            return $"{{{nameof(Settore)}={Settore}, {nameof(Nome)}={Nome}, {nameof(Cognome)}={Cognome}, {nameof(Stipendio)}={Stipendio.ToString()}}}";
        }
        


    }
}
