﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PotosiEsercitazione
{
    class ResponsabileVenditori : Venditore
    {
        public string Venditori { get; set; }
        public List<Venditore> AggiungiVenditore(Venditore venditore)
        {
            venditore.Nome = "Brian";
            venditore.Cognome = "Potosi";
            venditore.Stipendio = 35000;
            venditore.Settore = "Auto";

            List<Venditore> lista = new List<Venditore>();
            lista.Add(venditore);
            return lista;
        }
        public List<Venditore> RestituisceVenditore(int index)
        {
            index = 0;
            return lista[0];
        }
        public List<Venditore> CancellaVenditore(int index)
        {
            index = 0;
            lista[0] = null;            
        }
        public override double Tredicesima()
        {
            Stipendio = Stipendio * 2;
            return base.Tredicesima();

        }
    }
}
