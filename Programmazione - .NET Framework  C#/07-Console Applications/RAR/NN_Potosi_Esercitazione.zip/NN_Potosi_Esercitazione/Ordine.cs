﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PotosiEsercitazione
{
    sealed class Ordine
    {
        public int IdOrdine { get; set; }
        public DateTime Data { get; set; }
        public List<Prodotto> ElencoProdotti { get; set; }
        public Venditore venditore { get; set; }
        public int NoProdotti()
        {
            int a = ElencoProdotti.Count;
            return a;
        }
        public int Scontrino()
        {

        }
    }
}
