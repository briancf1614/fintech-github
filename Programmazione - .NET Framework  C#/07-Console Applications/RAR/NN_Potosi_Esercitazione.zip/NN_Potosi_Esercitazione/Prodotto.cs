﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PotosiEsercitazione
{
    class Prodotto
    {
        public int Codice { get; set; }
        public string Prodotto2 { get; set; }
        public string Descrizione { get; set; }
        public int prezzo { get; set; }

    }
}
