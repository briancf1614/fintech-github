﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PotosiEsercitazione
{
    class CapoOfficina
    {
        public List<Ordine> Ordini;
        public abstract AggiungiOrdine(Ordine ordine, int index);
        public int NoOrdini()
        {

        }
        public override double Tredicesima()
        {
            Stipendio = Stipendio * 2;
        }

    }
}
