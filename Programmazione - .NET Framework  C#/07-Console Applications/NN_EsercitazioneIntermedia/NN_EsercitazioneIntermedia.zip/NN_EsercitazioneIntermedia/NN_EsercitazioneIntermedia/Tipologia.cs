﻿namespace NN_EsercitazioneIntermedia
{
    enum Tipologia
    {
        CARROZZERIA,MECCANICA
    }
}