﻿namespace NN_EsercitazioneIntermedia
{
    enum Settore
    {
        AUTO, MOTO
    }
}