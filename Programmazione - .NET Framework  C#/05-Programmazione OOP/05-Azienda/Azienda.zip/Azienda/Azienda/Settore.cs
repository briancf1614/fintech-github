﻿namespace Azienda
{
    enum Settore
    {
        INSTALLATORE,MANUTENTORE
    }
}