﻿using System;

namespace ClasseTriangolo
{
    class Program
    {
        static void Main(string[] args)
        {
            Triangolo t = new Triangolo() { Lato1 = 12, Lato2 = 3, Lato3 = 2 };

            Console.WriteLine(t);
        }
    }
}
