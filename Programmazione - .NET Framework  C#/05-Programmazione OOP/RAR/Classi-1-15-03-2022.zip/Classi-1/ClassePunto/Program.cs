﻿using System;

namespace ClassePunto
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            
            punto P(2,3)

            ToString()
            (,)
            (2,3)
            P(2,-3.25)

            distanza dall'origine degli assi
            distanza da un altro punto



             */


            Console.WriteLine("Hello World!");
        }
    }
}
