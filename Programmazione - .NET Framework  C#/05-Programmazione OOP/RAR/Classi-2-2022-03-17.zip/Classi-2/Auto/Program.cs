﻿using System;

namespace Auto
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             marca, modello, cilindrata, alimentazione,colore

            metodo che restituisce la velocità max

            calcolo cilindrata/10 e aggiungo bonus che è determinato dall'alimentazione

            se benzina => 30
            se Diesel => 20
            se GPL => -10
            se metano => -30           
             
             */

            var a = new Auto { Alimentazione = Alimentazione.GPL, Marca = "BMW", Modello = "X5", Cilindrata = 2000, Colore = "Verde" };

            Console.WriteLine(a);
        }
    }
}
