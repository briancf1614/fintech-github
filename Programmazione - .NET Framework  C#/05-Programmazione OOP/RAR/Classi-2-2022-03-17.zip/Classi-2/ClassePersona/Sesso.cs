﻿namespace ClassePersona
{
    enum Sesso
    {
        ALTRO,F,M
    }
}