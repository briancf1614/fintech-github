﻿using System;

namespace ClasseCerchio
{
    class Program
    {
        static void Main(string[] args)
        {
            Cerchio c1 = new Cerchio() { Raggio = 1.25 };
            Console.WriteLine(c1);
        }
    }
}
