﻿using MVC_BikeStores.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_BikeStores.Controllers
{
    public class StaffsController : Controller
    {
        private BikeStoresContext db = new BikeStoresContext();
        public ActionResult Index()
        {
            var staffs = db.Staffs.OrderBy(x => x.Last_Name).ToList();
            return View(staffs);
        }
    }
}