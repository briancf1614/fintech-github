﻿using MVC_BikeStores.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace MVC_BikeStores.Controllers
{
    public class ProductsController : Controller
    {
        private BikeStoresContext db = new BikeStoresContext();
        public ActionResult Index()
        {
            var products = db.Products.OrderBy(x => x.Product_Name).ToList();
            return View(products);
        }


        public ActionResult Details(int id)
        {
            var product = db.Products.Find(id);
            return View(product);
        }



        public ActionResult ProductsListByBrand(int? id)
        {
            //id = brand_id

            if (id == null)
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            var products = db.Products.Where(x => x.Brand_Id == id).OrderBy(x => x.Product_Name).ToList();

            if (products == null)
                return HttpNotFound();

            return View("Index", products);
        }

    }
}