﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_PrestitoBiblioteca.Controllers
{
    [Authorize(Roles ="Administrators,Users")]
    public class DashBoardController : Controller
    {
        // GET: DashBoard
        public ActionResult Index()
        {
            return View();
        }

        //[Authorize(Roles ="Users")]
        public ActionResult Studente()
        {
            return View();
        }
    }
}