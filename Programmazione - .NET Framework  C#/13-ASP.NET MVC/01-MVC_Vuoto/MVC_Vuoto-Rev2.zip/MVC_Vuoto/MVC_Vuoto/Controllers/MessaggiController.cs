﻿using MVC_Vuoto.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_Vuoto.Controllers
{
    public class MessaggiController : Controller
    {
        // GET: Messaggi
        public ActionResult Index()
        {
            return View();
        }

        //GET
        //Creo il form per consentire l'invio di un messaggio
        public ActionResult FormMessaggio() {

            return View();        
        }

        //POST
        //Recupero i dati del form che sono stati inviati
        public ActionResult RecuperoMessaggio(MessaggioViewModel messaggio) {

            return View(messaggio);
        }
    }
}