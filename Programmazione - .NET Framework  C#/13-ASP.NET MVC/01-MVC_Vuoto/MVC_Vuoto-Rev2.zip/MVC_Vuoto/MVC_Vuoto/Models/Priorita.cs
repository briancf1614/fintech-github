﻿namespace MVC_Vuoto
{
    public enum Priorita
    {
        Bassa,Normale,Alta
    }
}