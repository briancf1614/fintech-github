﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC_Vuoto.Models
{
    public class MessaggioViewModel
    {
        /*
            email mittente
            email destinatario
            oggetto
            testo
            priorita(bassa, normale, alta)
            data 
        */

        public string Mittente { get; set; }
        public string Destinatario { get; set; }
        public string Oggetto { get; set; }
        public string Testo { get; set; }

        public Priorita Priorita { get; set; }
        public DateTime Data { get; set; }

        public MessaggioViewModel()
        {
            Data = DateTime.Now;
            Priorita = Priorita.Normale;
        }

        public override string ToString()
        {
            return $"{{{nameof(Mittente)}={Mittente}, {nameof(Destinatario)}={Destinatario}, {nameof(Oggetto)}={Oggetto}, {nameof(Testo)}={Testo}, {nameof(Priorita)}={Priorita.ToString()}, {nameof(Data)}={Data.ToString()}}}";
        }
    }
}