﻿using GAM_Collezioni.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace GAM_Collezioni.Controllers
{
    public class MostreController : Controller
    {
        private CollezioniContext db = new CollezioniContext();

        // GET: Mostre
        public ActionResult Index(string cercaTitolo,string cercaTecnica,string cercaAutore)
        {
            var mostre = db.Mostre.Include("Autore").Take(10).ToList();

            var tecniche = db.Mostre.Include("Autore").Select(x => x.Tecnica).Distinct().ToList();
            ViewBag.cercaTecnica = new SelectList(tecniche);

            var autori = db.Autori.Select(x => x.Nominativo).ToList();
            ViewBag.cercaAutore = new SelectList(autori);

            //cerca per titolo
            if (!string.IsNullOrEmpty(cercaTitolo))
                mostre = db.Mostre.Include("Autore").Where(t => t.Titolo.ToLower().Contains(cercaTitolo.ToLower())).ToList();

            //cerca per tecnica
            if (!string.IsNullOrEmpty(cercaTecnica))
                mostre = db.Mostre.Include("Autore").Where(t => t.Tecnica.Equals(cercaTecnica,StringComparison.OrdinalIgnoreCase)).ToList();

            //cerca per autore
            if (!string.IsNullOrEmpty(cercaAutore))
                mostre = db.Mostre.Include("Autore").Where(t => t.Autore.Nominativo.Equals(cercaAutore)).ToList();

            return View(mostre);
        }

        public ActionResult Dettaglio(int id)
        {
            var mostra = db.Mostre.Include("Autore").Where(x => x.Id==id).FirstOrDefault();
            return View(mostra);
        }
    }
}