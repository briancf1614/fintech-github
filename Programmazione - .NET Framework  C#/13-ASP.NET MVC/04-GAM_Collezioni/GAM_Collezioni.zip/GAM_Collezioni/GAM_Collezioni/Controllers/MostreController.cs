﻿using GAM_Collezioni.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace GAM_Collezioni.Controllers
{
    public class MostreController : Controller
    {
        private CollezioniContext db = new CollezioniContext();

        // GET: Mostre
        public ActionResult Index()
        {
            var mostre = db.Mostre.Take(10).ToList();
            return View(mostre);
        }

        public ActionResult Dettaglio(int id)
        {
            var mostra = db.Mostre.Find(id);
            return View(mostra);
        }
    }
}