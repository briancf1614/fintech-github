﻿using MVC_EF_DatabaseFirst.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_EF_DatabaseFirst.Controllers
{
    public class ClassiController : Controller
    {
        private EF_AnagraficaEntities db = new EF_AnagraficaEntities();
        // GET: Classi
        public ActionResult Index()
        {
            return View(db.Studente.ToList());
        }

        public ActionResult ElencoPerClasse(string classe) {
            return View(db.Studente.Where(c=>c.Classe==classe).ToList());
        }
    }
}