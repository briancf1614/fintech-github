﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC_EF_DatabaseFirst.Models
{
    public class Classe
    {
        public string Denominazione { get; set; }
        public int NumeroStudenti { get; set; }
    }
}