﻿using MVC_EF_DatabaseFirst.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_EF_DatabaseFirst.Controllers
{
    [Authorize(Roles ="Administrators")]
    public class DashBoardController : Controller
    {
        private EF_AnagraficaEntities db = new EF_AnagraficaEntities();

        // GET: DashBoard
        public ActionResult Index()
        {
            ViewBag.NumeroStudenti=db.Studente.Count();
            return View();
        }
        public ActionResult ElencoClassiNumeroStudenti()
        {
            var lista = new List<Classe>();

            var classe = db.Studente.Select(x => x.Classe).Distinct().ToList();

            foreach (var c in classe)
                lista.Add(new Classe { Denominazione=c, NumeroStudenti=db.Studente.Where(x => x.Classe==c).ToList().Count() });
                       
            return View(lista);
        }

    }
}